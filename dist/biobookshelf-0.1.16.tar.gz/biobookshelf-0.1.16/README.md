Bio-Bookshelf

a collection of python scripts and functions for exploratory 
analysis of bioinformatic data in Python

from biobookshelf.main import *
from biobookshelf import *

def main( ) :
    print( "[biobookshelf] main function loaded" )

if __name__ == "__main__" :
    main( )
    
